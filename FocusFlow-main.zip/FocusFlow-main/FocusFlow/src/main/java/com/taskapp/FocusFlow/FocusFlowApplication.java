package com.taskapp.FocusFlow;

//import java.util.*;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
//import org.springframework.web.bind.annotation.GetMapping;

//import com.taskapp.FocusFlow.model.Task;
//import com.taskapp.FocusFlow.repo.TaskRepository;

@SpringBootApplication

//Not sure if command line runner goes in this file
public class FocusFlowApplication {
	
	public static void main(String[] args) {
	    SpringApplication.run(FocusFlowApplication.class, args);
	    
	  }
	
//	@GetMapping("/")
//	public String apiRoot() {
//		return "FocusFlow: "
//				+ "The application where you can organize your tasks!";
//	}

}



  
